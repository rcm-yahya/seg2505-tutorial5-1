@Test
public void firstIsInvalid() {
    onView(withId(R.id.username)).perform(typeText("user1"), closeSoftKeyboard());
    onView(withId(R.id.loginBtn)).perform(click());
    onView(withText("Invalid First Name")).check(matches(isDisplayed()));
}